#!/bin/bash
# NexoTrace Defence — Quick Setup Script
# Run this once after cloning/downloading the project

echo "========================================"
echo "  NexoTrace Defence — Setup Script"
echo "========================================"

# 1. Install dependencies
echo ""
echo "[1/4] Installing Python dependencies..."
pip install -r requirements.txt

# 2. Run migrations
echo ""
echo "[2/4] Running database migrations..."
python manage.py makemigrations scanner
python manage.py migrate

# 3. Create superuser (optional)
echo ""
echo "[3/4] Creating admin superuser (optional)..."
echo "      (Press Ctrl+C to skip)"
python manage.py createsuperuser

# 4. Start server
echo ""
echo "[4/4] Starting development server..."
echo ""
echo "  ✅  Visit: http://127.0.0.1:8000/"
echo "  ✅  Admin: http://127.0.0.1:8000/admin/"
echo ""
python manage.py runserver

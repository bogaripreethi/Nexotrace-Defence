# 🛡️ NexoTrace Defence
### AI-Powered Cybersecurity & Threat Detection Platform

A full-stack Django web application for detecting digital threats including scam messages, phishing emails, malware files, unsafe URLs, fake profiles, and deepfake images.

---

## 🚀 Quick Start

### Prerequisites
- Python 3.9+
- pip

### Installation

```bash
# 1. Navigate to the project folder
cd nexotrace

# 2. (Recommended) Create a virtual environment
python -m venv venv
source venv/bin/activate        # Linux/Mac
venv\Scripts\activate           # Windows

# 3. Install dependencies
pip install -r requirements.txt

# 4. Apply database migrations
python manage.py makemigrations scanner
python manage.py migrate

# 5. Create an admin account (optional)
python manage.py createsuperuser

# 6. Run the server
python manage.py runserver
```

Open your browser at **http://127.0.0.1:8000/**

---

## 📁 Project Structure

```
nexotrace/
├── manage.py
├── requirements.txt
├── setup_and_run.sh
├── db.sqlite3              (auto-created after migrate)
│
├── nexotrace_project/      # Django project config
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
│
├── scanner/                # Main application
│   ├── models.py           # ScanHistory model
│   ├── views.py            # All view logic
│   ├── urls.py             # URL routing
│   ├── forms.py            # Django forms
│   ├── detection.py        # Core detection algorithms
│   └── admin.py            # Admin panel config
│
└── templates/              # HTML templates
    ├── base.html           # Sidebar layout, styles
    ├── registration/
    │   ├── login.html
    │   └── register.html
    └── scanner/
        ├── dashboard.html
        ├── history.html
        ├── message_scanner.html
        ├── email_scanner.html
        ├── file_scanner.html
        ├── url_scanner.html
        ├── profile_scanner.html
        └── deepfake_scanner.html
```

---

## ✨ Features

| Feature | Description |
|---|---|
| 🔐 Auth System | Register, Login, Logout, Remember Me, Session management |
| 📊 Dashboard | Stats, Chart.js bar/pie charts, recent activity |
| 💬 Message Scanner | Detects scam/spam with keyword highlighting |
| 📧 Email Scanner | Identifies phishing emails and suspicious links |
| 📄 File Scanner | Scans TXT/PDF files for malware patterns |
| 🔗 URL Scanner | Checks URLs for 7+ threat indicators |
| 👤 Fake Profile Detector | Uses `difflib` similarity against 30+ real profiles |
| 🖼️ Deepfake Checker | Heuristic analysis of uploaded images |
| 🕰️ Scan History | Full filterable history with timestamps |

---

## 🧠 Detection Logic

### Message/Email Scanner
Checks against 25+ scam keywords and 25+ phishing phrases. Results: **Safe / Suspicious / Scam / Phishing**

### File Scanner
Scans for 30+ malware patterns including shell commands, SQL injection, XSS, and script injections.

### URL Scanner
Checks 7 indicators: IP-based URLs, shorteners, suspicious keywords, subdomain spoofing, `@` symbol, double slashes, HTTP protocol.

### Fake Profile Detector
Uses Python's `difflib.SequenceMatcher` to compare input against 30+ celebrity profiles:
- Score ≥ 80% → **Fake**
- Score 60–79% → **Suspicious**
- Score < 60% → **Real / Original**

### Deepfake Checker
Heuristic analysis based on: filename patterns, file size anomalies, uncommon formats.

---

## 🗄️ Database Model

```python
class ScanHistory(models.Model):
    user       = ForeignKey(User)
    scan_type  = CharField  # message/email/file/url/profile/deepfake
    input_data = TextField
    result     = CharField  # safe/scam/phishing/suspicious/unsafe/fake/etc.
    details    = TextField
    timestamp  = DateTimeField(auto_now_add=True)
```

---

## 🎨 Tech Stack

- **Backend:** Django 4.2, Python 3.9+, SQLite
- **Frontend:** Bootstrap 5.3, Chart.js 4, Bootstrap Icons
- **Fonts:** Space Grotesk + JetBrains Mono (Google Fonts)
- **Detection:** Python `re`, `difflib`, custom keyword databases

---

## 🔧 Configuration

Edit `nexotrace_project/settings.py`:
- Change `SECRET_KEY` for production
- Set `DEBUG = False` for production
- Configure `DATABASES` for PostgreSQL/MySQL if needed
- Set `ALLOWED_HOSTS` for your domain

---

## 📝 Usage Tips

1. **Register** a new account at `/register/`
2. Navigate using the **sidebar** to any scanner
3. View your **history** at `/history/` with type filters
4. Access the **Django Admin** at `/admin/` (superuser required)

---

## ⚠️ Disclaimer

This tool uses heuristic and keyword-based detection. It is intended for educational and demonstration purposes. For production cybersecurity systems, integrate with professional threat intelligence APIs (VirusTotal, Google Safe Browsing, etc.) and train/deploy ML models.

---

*Built with Django + Bootstrap · NexoTrace Defence Platform*

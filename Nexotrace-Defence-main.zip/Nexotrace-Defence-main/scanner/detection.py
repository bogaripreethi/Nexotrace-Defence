import re
import difflib
import os

# ─────────────────────────────────────────────
# KEYWORD DATABASES
# ─────────────────────────────────────────────

SCAM_KEYWORDS = [
    'winner','won','prize','lottery','claim','free money','congratulations',
    'click here','urgent','limited time','act now','offer expires','selected',
    'cash reward','bank transfer','wire transfer','nigerian prince','inheritance',
    'million dollars','send money','gift card','western union','money gram',
    'you have been chosen','secret shopper','work from home','make money fast',
    'double your money','risk free','guaranteed profit','investment opportunity',
    'verify your account','confirm your details','suspended account','password expired'
]

PHISHING_KEYWORDS = [
    'verify your account','update your information','suspended','click to confirm',
    'login to continue','your account has been','security alert','unusual activity',
    'confirm your identity','reset your password','bank account','credit card',
    'social security','paypal','amazon','apple id','microsoft account',
    'your payment failed','invoice attached','refund','tax return','irs',
    'beneficiary','inheritance','kindly provide','dear customer','valued customer'
]

PHISHING_DOMAINS = [
    'bit.ly','tinyurl','goo.gl','t.co','ow.ly','is.gd','buff.ly',
    'adf.ly','shorte.st','linkbucks','bc.vc',
]

SUSPICIOUS_URL_PATTERNS = [
    'login','signin','verify','secure','account','update','confirm',
    'banking','paypal','ebay','amazon','apple','google','microsoft',
    'password','credential','validate','authenticate','webscr','cmd=',
    'support','helpdesk','service','access','portal','admin'
]

MALWARE_KEYWORDS = [
    'exec(','eval(','system(','shell_exec','passthru','base64_decode',
    'rm -rf','format c:','del /f','wget http','curl http','chmod 777',
    'nc -e','netcat','reverse shell','/etc/passwd','/etc/shadow',
    'cmd.exe','powershell','regsvr32','mshta','wscript','cscript',
    '<script>','javascript:','vbscript:','onload=','onerror=',
    'document.cookie','window.location','iframe src','sql injection',
    'drop table','union select','1=1','or 1=1','; --','xp_cmdshell'
]



# ─────────────────────────────────────────────
# OTHER FUNCTIONS (UNCHANGED)
# ─────────────────────────────────────────────

def detect_message_scam(text):
    text_lower = text.lower()
    found_keywords = [kw for kw in SCAM_KEYWORDS if kw in text_lower]

    if len(found_keywords) >= 3:
        verdict = 'scam'
    elif len(found_keywords) >= 1:
        verdict = 'suspicious'
    else:
        verdict = 'safe'

    highlighted = highlight_keywords(text, found_keywords)
    details = f"Found {len(found_keywords)} suspicious keyword(s)"
    return verdict, details, highlighted, found_keywords


def detect_phishing_email(text):
    text_lower = text.lower()
    found_keywords = [kw for kw in PHISHING_KEYWORDS if kw in text_lower]

    urls = re.findall(r'https?://[^\s<>"\']+', text, re.IGNORECASE)
    suspicious_links = []

    for url in urls:
        for pattern in SUSPICIOUS_URL_PATTERNS:
            if pattern in url.lower():
                suspicious_links.append(url)

    total_flags = len(found_keywords) + len(suspicious_links)

    if total_flags >= 3:
        verdict = 'phishing'
    elif total_flags >= 1:
        verdict = 'suspicious'
    else:
        verdict = 'safe'

    details = " | ".join(found_keywords[:3]) if found_keywords else "No phishing detected"
    highlighted = highlight_keywords(text, found_keywords)
    return verdict, details, highlighted, found_keywords


def scan_file_content(content, filename=''):
    content_lower = content.lower()
    found_keywords = [kw for kw in MALWARE_KEYWORDS if kw in content_lower]

    if len(found_keywords) >= 3:
        verdict = 'malware'
    elif len(found_keywords) >= 1:
        verdict = 'suspicious'
    else:
        verdict = 'safe'

    details = "Malware patterns found" if found_keywords else "No malware"
    return verdict, details, found_keywords





# ─────────────────────────────────────────────
# 🔥 REALISTIC DEEPFAKE DETECTOR
# ─────────────────────────────────────────────

from PIL import Image
import numpy as np

def scan_url(url):
    """Scan URL for phishing and malicious patterns"""
    flags = []
    url_lower = url.lower()
    
    # Check for URL shortening services
    for domain in PHISHING_DOMAINS:
        if domain in url_lower:
            flags.append(f"URL shortener detected: {domain}")
    
    # Check for suspicious URL patterns
    for pattern in SUSPICIOUS_URL_PATTERNS:
        if pattern in url_lower:
            flags.append(f"Suspicious pattern: {pattern}")
    
    # Check for phishing keywords in URL
    found_keywords = [kw for kw in PHISHING_KEYWORDS if kw in url_lower]
    for kw in found_keywords:
        flags.append(f"Phishing keyword: {kw}")
    
    # Determine verdict based on flags
    if len(flags) >= 3:
        verdict = 'phishing'
    elif len(flags) >= 1:
        verdict = 'suspicious'
    else:
        verdict = 'safe'
    
    details = " | ".join(flags[:3]) if flags else "No threats detected"
    
    return verdict, details, flags


def check_deepfake_image(image_file):
    flags = []

    try:
        img = Image.open(image_file).convert('RGB')
        img_array = np.array(img)

        # 1. Color variation check
        std_dev = np.std(img_array)
        if std_dev < 40:
            flags.append("Low color variation (AI-like smoothing)")

        # 2. Edge detail check
        edges = np.mean(np.abs(np.diff(img_array, axis=0)))
        if edges < 10:
            flags.append("Low edge detail (possible AI image)")

        # 3. Resolution pattern check
        width, height = img.size
        if width % 64 == 0 and height % 64 == 0:
            flags.append("AI resolution pattern")

    except:
        flags.append("Error reading image")

    # Final result
    if len(flags) >= 1:
        verdict = 'FAKE ⚠️'
    else:
        verdict = 'SAFE ✅'

    details = " | ".join(flags) if flags else "Looks like real image"

    return verdict, details, flags
# ─────────────────────────────────────────────
# HELPER
# ─────────────────────────────────────────────

def highlight_keywords(text, keywords):
    for kw in keywords:
        text = re.sub(kw, f"<mark>{kw}</mark>", text, flags=re.IGNORECASE)
    return text
from django.urls import path
from . import views

urlpatterns = [
    path('', views.login_view, name='home'),
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('history/', views.history, name='history'),
    path('scan/message/', views.scan_message, name='scan_message'),
    path('scan/email/', views.scan_email, name='scan_email'),
    path('scan/file/', views.scan_file, name='scan_file'),
    path('scan/url/', views.scan_url_view, name='scan_url'),
    
    path('scan/deepfake/', views.scan_deepfake, name='scan_deepfake'),
]

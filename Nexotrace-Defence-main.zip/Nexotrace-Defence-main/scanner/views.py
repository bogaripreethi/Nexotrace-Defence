import os
import json
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.db.models import Count, Q

from .models import ScanHistory
from .forms import (
    RegisterForm, MessageScanForm, EmailScanForm,
    FileScanForm, URLScanForm,  DeepfakeScanForm
)
from .detection import (
    detect_message_scam, detect_phishing_email,
    scan_file_content, check_deepfake_image, scan_url
)


# ─────────────────────────────────────────────
# AUTH VIEWS
# ─────────────────────────────────────────────

def register_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, f'Welcome to NexoTrace, {user.username}! Your account is ready.')
            return redirect('dashboard')
        else:
            messages.error(request, 'Please fix the errors below.')
    else:
        form = RegisterForm()
    return render(request, 'registration/register.html', {'form': form})


def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '')
        remember_me = request.POST.get('remember_me')

        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            if not remember_me:
                request.session.set_expiry(0)
            messages.success(request, f'Welcome back, {user.username}!')
            return redirect(request.GET.get('next', 'dashboard'))
        else:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'registration/login.html')


def logout_view(request):
    logout(request)
    messages.info(request, 'You have been logged out successfully.')
    return redirect('login')


# ─────────────────────────────────────────────
# DASHBOARD
# ─────────────────────────────────────────────

@login_required
def dashboard(request):
    user_scans = ScanHistory.objects.filter(user=request.user)

    total_scans = user_scans.count()
    safe_count = user_scans.filter(result__in=['safe', 'real']).count()
    threat_count = total_scans - safe_count

    # Scan type breakdown for bar chart
    scan_type_counts = {}
    for scan_type, _ in ScanHistory.SCAN_TYPES:
        scan_type_counts[scan_type] = user_scans.filter(scan_type=scan_type).count()

    # Result breakdown for pie chart
    result_breakdown = {
        'safe': user_scans.filter(result__in=['safe', 'real']).count(),
        'suspicious': user_scans.filter(result='suspicious').count(),
        'threat': user_scans.filter(result__in=['scam', 'phishing', 'unsafe', 'fake', 'malware', 'deepfake']).count(),
    }

    recent_scans = user_scans[:10]

    context = {
        'total_scans': total_scans,
        'safe_count': safe_count,
        'threat_count': threat_count,
        'scan_type_counts_json': json.dumps(scan_type_counts),
        'result_breakdown_json': json.dumps(result_breakdown),
        'recent_scans': recent_scans,
    }
    return render(request, 'scanner/dashboard.html', context)


# ─────────────────────────────────────────────
# SCAN HISTORY
# ─────────────────────────────────────────────

@login_required
def history(request):
    scan_type_filter = request.GET.get('type', '')
    all_scans = ScanHistory.objects.filter(user=request.user)
    if scan_type_filter:
        all_scans = all_scans.filter(scan_type=scan_type_filter)
    context = {
        'scans': all_scans,
        'scan_types': ScanHistory.SCAN_TYPES,
        'active_filter': scan_type_filter,
    }
    return render(request, 'scanner/history.html', context)


# ─────────────────────────────────────────────
# MESSAGE SCANNER
# ─────────────────────────────────────────────

@login_required
def scan_message(request):
    form = MessageScanForm()
    result_data = None

    if request.method == 'POST':
        form = MessageScanForm(request.POST)
        if form.is_valid():
            text = form.cleaned_data['message']
            verdict, details, highlighted, keywords = detect_message_scam(text)

            ScanHistory.objects.create(
                user=request.user,
                scan_type='message',
                input_data=text[:500],
                result=verdict,
                details=details
            )

            result_data = {
                'verdict': verdict,
                'details': details,
                'highlighted': highlighted,
                'keywords': keywords,
            }

    return render(request, 'scanner/message_scanner.html', {'form': form, 'result': result_data})


# ─────────────────────────────────────────────
# EMAIL SCANNER
# ─────────────────────────────────────────────

@login_required
def scan_email(request):
    form = EmailScanForm()
    result_data = None

    if request.method == 'POST':
        form = EmailScanForm(request.POST)
        if form.is_valid():
            content = form.cleaned_data['email_content']
            verdict, details, highlighted, keywords = detect_phishing_email(content)

            ScanHistory.objects.create(
                user=request.user,
                scan_type='email',
                input_data=content[:500],
                result=verdict,
                details=details
            )

            result_data = {
                'verdict': verdict,
                'details': details,
                'highlighted': highlighted,
                'keywords': keywords,
            }

    return render(request, 'scanner/email_scanner.html', {
        'form': form,
        'result': result_data,
        'check_items': [
            "Phishing keywords and phrases",
            "Suspicious embedded links",
            "Urgent language patterns",
            "Social engineering tactics",
            "Impersonation of trusted brands"
        ]
    })


# ─────────────────────────────────────────────
# FILE SCANNER
# ─────────────────────────────────────────────

@login_required
def scan_file(request):
    form = FileScanForm()
    result_data = None

    if request.method == 'POST':
        form = FileScanForm(request.POST, request.FILES)
        if form.is_valid():
            uploaded_file = request.FILES['file']
            filename = uploaded_file.name
            ext = os.path.splitext(filename)[1].lower()

            try:
                if ext == '.txt':
                    content = uploaded_file.read().decode('utf-8', errors='ignore')
                elif ext == '.pdf':
                    raw = uploaded_file.read()
                    content = raw.decode('latin-1', errors='ignore')
                else:
                    content = uploaded_file.read().decode('utf-8', errors='ignore')

                verdict, details, keywords = scan_file_content(content, filename)

                ScanHistory.objects.create(
                    user=request.user,
                    scan_type='file',
                    input_data=f"File: {filename} ({uploaded_file.size} bytes)",
                    result=verdict,
                    details=details
                )

                result_data = {
                    'verdict': verdict,
                    'details': details,
                    'keywords': keywords,
                    'filename': filename,
                    'filesize': uploaded_file.size,
                }
            except Exception as e:
                messages.error(request, f'Error reading file: {str(e)}')

    return render(request, 'scanner/file_scanner.html', {
        'form': form,
        'result': result_data,
        'check_items': [
            "Malicious scripts",
            "Hidden links",
            "Executable patterns",
            "Suspicious keywords",
            "File extension risk"
        ]
    })


# ─────────────────────────────────────────────
# URL SCANNER
# ─────────────────────────────────────────────

@login_required
def scan_url_view(request):
    form = URLScanForm()
    result_data = None

    if request.method == 'POST':
        form = URLScanForm(request.POST)
        if form.is_valid():
            url = form.cleaned_data['url']
            verdict, details, flags = scan_url(url)

            ScanHistory.objects.create(
                user=request.user,
                scan_type='url',
                input_data=url,
                result=verdict,
                details=details
            )

            result_data = {
                'verdict': verdict,
                'details': details,
                'flags': flags,
                'url': url,
            }

    return render(request, 'scanner/url_scanner.html', {
        'form': form,
        'result': result_data,
        'check_items': [
            "Suspicious domain names",
            "Shortened URLs",
            "HTTPS security check",
            "Phishing keywords in URL",
            "Blacklist patterns"
        ]
    })

# ─────────────────────────────────────────────
# DEEPFAKE IMAGE CHECKER
# ─────────────────────────────────────────────

@login_required
def scan_deepfake(request):
    form = DeepfakeScanForm()
    result_data = None

    if request.method == 'POST':
        form = DeepfakeScanForm(request.POST, request.FILES)
        if form.is_valid():
            image = request.FILES['image']

            # 🔥 CALL FUNCTION
            verdict, details, flags = check_deepfake_image(image)

            # ✅ NO OVERRIDE HERE

            ScanHistory.objects.create(
                user=request.user,
                scan_type='deepfake',
                input_data=f"Image: {image.name} ({image.size} bytes)",
                result=verdict,
                details=details
            )

            result_data = {
                'verdict': verdict,
                'details': details,
                'flags': flags,
                'filename': image.name,
                'filesize': image.size,
            }

    return render(request, 'scanner/deepfake_scanner.html', {
        'form': form,
        'result': result_data,
        'check_items': [
            "Face inconsistencies",
            "Lighting mismatch",
            "Blurred edges",
            "AI-generated patterns",
            "Metadata anomalies"
        ]
    })
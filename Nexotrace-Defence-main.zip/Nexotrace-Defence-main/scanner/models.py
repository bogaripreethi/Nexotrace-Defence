from django.db import models
from django.contrib.auth.models import User


class ScanHistory(models.Model):
    SCAN_TYPES = [
        ('message', 'Message Scanner'),
        ('email', 'Email Scanner'),
        ('file', 'File Scanner'),
        ('url', 'URL Scanner'),
        
        ('deepfake', 'Deepfake Image Checker'),
    ]

    RESULT_TYPES = [
        ('safe', 'Safe'),
        ('scam', 'Scam'),
        ('phishing', 'Phishing'),
        ('suspicious', 'Suspicious'),
        ('unsafe', 'Unsafe'),
        ('fake', 'Fake'),
        ('real', 'Real'),
        ('possibly_fake', 'Possibly Fake'),
        ('deepfake', 'Deepfake'),
        ('malware', 'Malware Detected'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='scans')
    scan_type = models.CharField(max_length=20, choices=SCAN_TYPES)
    input_data = models.TextField()
    result = models.CharField(max_length=30, choices=RESULT_TYPES)
    details = models.TextField(blank=True, null=True)
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-timestamp']

    def __str__(self):
        return f"{self.user.username} - {self.scan_type} - {self.result} ({self.timestamp:%Y-%m-%d %H:%M})"

    def is_threat(self):
        return self.result not in ['safe', 'real']

    def result_badge_class(self):
        safe_results = ['safe', 'real']
        warn_results = ['suspicious', 'possibly_fake']
        if self.result in safe_results:
            return 'badge-safe'
        elif self.result in warn_results:
            return 'badge-warn'
        else:
            return 'badge-danger'

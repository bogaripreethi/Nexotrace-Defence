from django.contrib import admin
from .models import ScanHistory


@admin.register(ScanHistory)
class ScanHistoryAdmin(admin.ModelAdmin):
    list_display = ['user', 'scan_type', 'result', 'timestamp']
    list_filter  = ['scan_type', 'result', 'timestamp']
    search_fields = ['user__username', 'input_data', 'result']
    ordering = ['-timestamp']
    readonly_fields = ['timestamp']
